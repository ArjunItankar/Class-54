import React, { Component } from 'react';
import { Button, View, Alert } from 'react-native';

export default class App extends Component {
  render(){
    return(
      <View>
      <View 
      style={{marginTop:150}}>
      <Button 
      title="Click me" 
      color="red"
       onPress{() => Alert.alert('Hello, how are you?')} />
      </View>
      </View>
    )
  }
}